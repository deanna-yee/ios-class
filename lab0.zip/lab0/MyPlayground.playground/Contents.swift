//Deanna Yee
//G01062883

//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//Add a line of code
let name = "Deanna Yee"

//Print in the debug area
print("\(str) \nHello, \(name)")

//Try Out Swift Data Types in the Playground
//Numbers:Int, Float, Double
let value = 42
let pi = 3.14

var numberOfStopLights:Int = 4
var population:Int
population = 5422

//Boolean: Bool
var boolean = true

//Text: String Character
var day = "Saturday"
let townName:String = "NoWhere"
let townDescription = "\(townName) has population of \(population) and \(numberOfStopLights) stopLights."

print(townDescription)

//Arrays
var arrayOfInts:[Int] = [1,2,3,4,5]
var names:[String] = ["Bob", "Jill", "Kate", "Jennifer"]
names.append("George")

//Initializers
let emptyString = String()
let defaultNumber = Int()
let defaultBool = Bool()
let number = 42
let meaningOfLife = String(number)

//Dictionaries
let nameByParkingSpace = [12:"George", 94:"Bill"]
let space12Name: String? = nameByParkingSpace[12]
let spaceName: String? = nameByParkingSpace[15]

