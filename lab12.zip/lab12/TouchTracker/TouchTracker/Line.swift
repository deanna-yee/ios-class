//
//  Line.swift
//  TouchTracker
//
//  Created by Deanna Yee on 11/7/16.
//  Copyright © 2016 cisstudent. All rights reserved.
//

import Foundation
import CoreGraphics

struct Line {
    var begin = CGPoint.zero
    var end = CGPoint.zero
}
