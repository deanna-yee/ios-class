//
//  CalculatorEngine.swift
//  UnitTestExample
//
//  Created by Deanna Yee on 11/12/16.
//  Copyright © 2016 cisstudent. All rights reserved.
//

import Foundation

class CalculatorEngine {
    
    func doubleNumber (number: Int) -> Int {
        return number * 2
        //return doubledNumber
    }
}
