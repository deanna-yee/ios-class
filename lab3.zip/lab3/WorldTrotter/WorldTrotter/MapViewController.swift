//
//  MapViewController.swift
//  WorldTrotter
//
//  Created by Deanna Yee on 9/7/16.
//  Copyright © 2016 cisstudent. All rights reserved.
//

//import Foundation

import UIKit

class MapViewController: UIViewController {
    
    //prints to the console when map view controller is selected the first time
    override func viewDidLoad(){
        //Always call the super implementation of viewDidLoad
        super.viewDidLoad()
        
        print("MapViewController loaded its view.")
    }
    
}
