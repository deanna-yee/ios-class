//
//  ScoreTabBarController.swift
//  Directional Simon Says
//
//  Created by Deanna Yee on 12/15/16.
//  Copyright © 2016 cisstudent. All rights reserved.
//

//import Foundation
import UIKit

class ScoreTabBarController: UITabBarController{
    
    var scoreStore: ScoreStore!
    
}
